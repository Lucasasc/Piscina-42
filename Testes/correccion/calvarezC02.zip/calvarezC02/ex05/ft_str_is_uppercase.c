/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dde-andr <dde-andr@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/07/07 11:31:35 by calvarez          #+#    #+#             */
/*   Updated: 2021/07/13 16:05:17 by dde-andr         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_str_is_uppercase (char *str)
{
	int	onlyAlfa;
	int	i;

	onlyAlfa = 1;
	i = 0;
	while (str[i] != '\0' && onlyAlfa != 0)
	{
		if ((str[i] < 'A' || str[i] > 'Z'))
		{
			onlyAlfa = 0;
		}
		i++;
	}
	return (onlyAlfa);
}
int		main(void)
{
	char *str_valid;
	char *str_invalid;

	str_valid = "HELLO";
	str_invalid = "HELLo";
	printf("should be 1: %d\n", ft_str_is_uppercase(str_valid));
	printf("should be 0: %d\n", ft_str_is_uppercase(str_invalid));
}