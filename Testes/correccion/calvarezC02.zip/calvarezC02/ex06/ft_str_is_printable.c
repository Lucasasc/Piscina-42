/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dde-andr <dde-andr@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/07/07 11:34:07 by calvarez          #+#    #+#             */
/*   Updated: 2021/07/13 16:05:32 by dde-andr         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_str_is_printable (char *str)
{
	int	onlyAlfa;
	int	i;

	onlyAlfa = 1;
	i = 0;
	while (str[i] != '\0' && onlyAlfa != 0)
	{
		if ((str[i] <= 31) || (str[i] == 127))
		{
			onlyAlfa = 0;
		}
		i++;
	}
	return (onlyAlfa);
}
int		main(void)
{
	char *str_valid;
	char *str_invalid;

	str_valid = "Hell0";
	str_invalid = "hello\7F";
	printf("should be 1: %d\n", ft_str_is_printable(str_valid));
	printf("should be 0: %d\n", ft_str_is_printable(str_invalid));
}