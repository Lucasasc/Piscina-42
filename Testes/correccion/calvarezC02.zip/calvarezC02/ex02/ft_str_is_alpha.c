/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dde-andr <dde-andr@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/07/06 16:46:40 by calvarez          #+#    #+#             */
/*   Updated: 2021/07/13 16:04:23 by dde-andr         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_str_is_alpha (char *str)
{
	int	onlyAlfa;
	int	i;

	onlyAlfa = 1;
	i = 0;
	while (str[i] != '\0' && onlyAlfa != 0)
	{
		if ((str[i] < 'A' || str[i] > 'z') || (str[i] >= '[' && str[i] <= '`'))
		{
			onlyAlfa = 0;
		}
		i++;
	}
	return (onlyAlfa);
}

int		main(void)
{
	char *str_valid;
	char *str_invalid;

	str_valid = "Hello";
	str_invalid = "Hell0";
	printf("should be 1: %d\n", ft_str_is_alpha(str_valid));
	printf("should be 0: %d\n", ft_str_is_alpha(str_invalid));
}